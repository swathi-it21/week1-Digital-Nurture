// Notifier.java
public interface Notifier {
    void send(String message);
}
